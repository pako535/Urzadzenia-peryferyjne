﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PCSC;
using PCSC.Iso7816;
using GsmComm.PduConverter;

namespace Karty_Chipowe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    
        static void CheckErr(SCardError err)
        {
            if (err != SCardError.Success)
                throw new PCSCException(err,SCardHelper.StringifyError(err));
        }

        void readCard()
        {
            //Kontekst.
            var context = new SCardContext();
            
            //Połączenie.
            context.Establish(SCardScope.System);
                
            //Pobranie czytników.
            var readerNames = context.GetReaders();
            if (readerNames == null || readerNames.Length < 1)
            {
                textBox1.Text += "Nie wykryto czytnika."+"\r\n";
                return;
            }
            else
            {
                textBox1.Text += "Wykryto czytnik.\n"+"\r\n";
            }

            //Wybranie czytnika.
            var readerName = readerNames[0];
            if (readerName == null)
            {
                textBox1.Text += "Nie można wybrać czytnika." + "\r\n";
                return;
            }
            else
            {
                textBox1.Text += "Wybrano czytnik." + "\r\n";
            }

            var rfidReader = new SCardReader(context);

            var sc = rfidReader.Connect(readerName, SCardShareMode.Shared, SCardProtocol.Any);
            if (sc != SCardError.Success)
            {
                textBox1.Text += "Nie mozna polaczyc sie z czytnikiem" + readerName + SCardHelper.StringifyError(sc) + "\r\n";
                return;
            }
            else
            {
                textBox1.Text += "Polaczono z czytnikiem."+"\r\n";
            }

            //Transakcja
            sc = rfidReader.BeginTransaction();
            if (sc != SCardError.Success)
            {
                textBox1.Text += "Nie mozna rozpoczac transkacji."+"\r\n";
                return;
            }
            else
            {
                textBox1.Text += "Rozpoczeto transkakcje." + "\r\n";
            }

            var receivePci = new SCardPCI();
            var sendPci = SCardPCI.GetPci(rfidReader.ActiveProtocol);

            var receiveBuffer = new byte[256];
            //  A0 20 00 01 08 31 31 31 31 FF FF FF FF (VERIFY CHV)
            var VERIFY_CHV = new byte[] { 0xA0, 0x20, 0x00, 0x01, 0x08, 0x30, 0x36, 0x37, 0x38, 0xFF, 0xFF, 0xFF, 0xFF };
            sc = rfidReader.Transmit(sendPci, VERIFY_CHV, receivePci, ref receiveBuffer);
            CheckErr(sc);
                    
            textBox2.Text += ("Odpowiedz (VERIFY_CHV): ");
            for (int i = 0; i < receiveBuffer.Length; i++)
                textBox2.Text += String.Format("{0:X2}", receiveBuffer[i]);

            textBox2.Text += "\r\n";

            receiveBuffer = new byte[256];
            // Send select telecom
            // A0 A4 00 00 02 7F 10 
            var SELECT_TELECOM = new byte[] { 0xA0, 0xA4, 0x00, 0x00, 0x02, 0x7F, 0x10 };
            sc = rfidReader.Transmit(sendPci, SELECT_TELECOM, receivePci, ref receiveBuffer);
            CheckErr(sc); // poprawka

            textBox2.Text +="Odpowiedz na Select Telekom: ";
            for (int i = 0; i < receiveBuffer.Length; i++)
                textBox2.Text += String.Format("{0:X2}", receiveBuffer[i]);

            textBox2.Text += "\r\n";

            receiveBuffer = new byte[256];
            // GET_RESPONSE
            var GET_RESPONSE = new byte[] { 0xA0, 0xC0, 0x00, 0x00, 0x16 };
            sc = rfidReader.Transmit(sendPci, GET_RESPONSE, receivePci, ref receiveBuffer);
            CheckErr(sc);

            textBox2.Text += "Odpowiedz na GET_RESPONSE: ";
            for (int i = 0; i < receiveBuffer.Length; i++)
                textBox2.Text += String.Format("{0:X2}", receiveBuffer[i]);

            textBox2.Text += "\r\n";

            receiveBuffer = new byte[256];
            // A0 A4 00 00 02 6F 3C SELECT SMS
            var SELECT_SMS = new byte[] { 0xA0, 0xA4, 0x00, 0x00, 0x02, 0x6F, 0x3C };
            sc = rfidReader.Transmit(sendPci, SELECT_SMS, receivePci, ref receiveBuffer);
            CheckErr(sc);

            textBox2.Text += ("Odpowiedz na Select sms: \n");
            for (int i = 0; i < receiveBuffer.Length; i++)
                textBox2.Text += String.Format("{0:X2}", receiveBuffer[i]);

            textBox2.Text += "\r\n";

            receiveBuffer = new byte[256];
            // GET RESPONSE
            GET_RESPONSE = new byte[] { 0xA0, 0xC0, 0x00, 0x00, 0x0F };
            sc = rfidReader.Transmit(sendPci, GET_RESPONSE, receivePci, ref receiveBuffer);
            CheckErr(sc);

            textBox2.Text += "Odpowiedz: ";
            for (int i = 0; i < receiveBuffer.Length; i++)
                textBox2.Text += String.Format("{0:X2}", receiveBuffer[i]);

            textBox2.Text += "\r\n";

            receiveBuffer = new byte[256];
            // READ RECORDS:
            // A0 B2 01 04 B0 READ RECORD number 01, absolute mode, 176 bytes, 0xB0
            string s = "";
            var READ_RECORD01 = new byte[] { 0xA0, 0xB2, 0x01, 0x04, 0xB0 };
            sc = rfidReader.Transmit(sendPci, READ_RECORD01, receivePci, ref receiveBuffer);
            CheckErr(sc);

            textBox3.Text += ("\r\nRecord 01: \n");
            for (int i = 0; i < receiveBuffer.Length; i++)
                s += String.Format("{0:X2}", receiveBuffer[i]);

            textBox3.Text += s + "\r\n";

            String s2 = "";
            receiveBuffer = new byte[256];
            var READ_RECORD02 = new byte[] { 0xA0, 0xB2, 0x02, 0x04, 0xB0 };
            sc = rfidReader.Transmit(sendPci, READ_RECORD02, receivePci, ref receiveBuffer);
            CheckErr(sc);

            textBox3.Text += ('\n' + "Record 02: \n");
            for (int i = 0; i < receiveBuffer.Length; i++)
                s2 += String.Format("{0:X2}", receiveBuffer[i]);

            textBox3.Text += s2 + '\n';


        // zakonczenie transakcji
        rfidReader.EndTransaction(SCardReaderDisposition.Leave);
       
        // odlaczenie karty
        rfidReader.Disconnect(SCardReaderDisposition.Reset);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            readCard();
        }
    }
}
